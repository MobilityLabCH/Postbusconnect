import assert from 'node:assert';
import test from 'node:test';

test('math', () => {
  assert.equal(1+1, 2);
});
