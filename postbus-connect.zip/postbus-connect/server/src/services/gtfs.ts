export function isOperable(from_stop_id: string, to_stop_id: string, date: string) {
  // v1: toujours vrai ; v2: vérifier GTFS & contraintes opérationnelles
  return true;
}
