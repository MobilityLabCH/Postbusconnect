# Security Policy

- Signalez toute vulnérabilité en ouvrant un ticket privé / security advisory.
- Ne divulguez pas publiquement avant correctif.
- Clés/API : n’ouvrez jamais de PR avec des secrets.
